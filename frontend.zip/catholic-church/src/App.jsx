
import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./HomePage";
import Login from "./components/form/Login";
import Signup from "./components/form/Signup";
import Layout from "./components/admin/Layout";
import Church_Layout from "./components/churchreader/Church_Layout"
import User_Layout from "./components/user/User_Layout"
import Award from "./components/user/pages/Award"
import Tasks from "./components/user/pages/Tasks"
import Courses from "./components/user/pages/Courses"
import Users from './components/admin/pages/Users';
import Course from './components/admin/pages/Course';
import Exams from './components/admin/pages/Exams';
import Awards from "./components/admin/pages/Awards"
import Task from "./components/admin/pages/Task"




import ChurchUsers from './components/churchreader/pages/ChurchUsers';
import ChurchCourse from './components/churchreader/pages/ChurchCourse';
import ChurchExams from './components/churchreader/pages/ChurchExams';
import AwardChurch from "./components/churchreader/pages/AwardChurch"
import ChurchTask from "./components/churchreader/pages/ChurchTask"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login/>} />
        <Route path="/signup" element={<Signup />} />

        {/* Admin */}

        <Route path='/admin' element={<Layout />}>
        <Route path='/admin/users' element={<Users />} />
        <Route path='/admin/tasks' element={<Task />} />
        <Route path='/admin/courses' element={<Course />} />
        <Route path='/admin/award' element={<Awards />} />
        <Route path='/admin/exams' element={<Exams />} />
        
        </Route>
        {/* End of admin Routes */}
        {/* Church reader */}
        <Route path='/churchReader' element={<Church_Layout />}>

        <Route path='/churchReader/users' element={<ChurchUsers />} />
        <Route path='/churchReader/tasks' element={<ChurchTask />} />
        <Route path='/churchReader/courses' element={<ChurchCourse />} />
        <Route path='/churchReader/award' element={<AwardChurch />} />
        <Route path='/churchReader/exams' element={<ChurchExams />} />

        </Route>
        {/* End of church Reader */}
        <Route path='/user' element={<User_Layout />}>
        <Route path='/user/award' element={<Award />} />
        <Route path='/user/tasks' element={<Tasks />} />
        <Route path='/user/courses' element={<Courses />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App

