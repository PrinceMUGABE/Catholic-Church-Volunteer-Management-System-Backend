import React from 'react'

function Profil() {
  return (
    <div>
      profile
    </div>
  )
}

export default Profil
