import React from 'react'

function Public() {
  return (
    <div>
      public
    </div>
  )
}

export default Public
