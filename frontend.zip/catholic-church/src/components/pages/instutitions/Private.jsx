import React from 'react'

function Private() {
  return (
    <div>
      private
    </div>
  )
}

export default Private
