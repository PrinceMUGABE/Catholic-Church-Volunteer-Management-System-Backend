import React from 'react'

function Pdf() {
  return (
    <div>
      Pdf
    </div>
  )
}

export default Pdf
