import React from 'react'

function Excell() {
  return (
    <div>
      Excell
    </div>
  )
}

export default Excell
