import React from 'react'

function Coment() {
  return (
    <div>
      coments
    </div>
  )
}

export default Coment
